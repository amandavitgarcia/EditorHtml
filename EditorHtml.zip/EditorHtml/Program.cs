﻿using System;

namespace EditorHtml
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu.Show();
        }
    }
}
